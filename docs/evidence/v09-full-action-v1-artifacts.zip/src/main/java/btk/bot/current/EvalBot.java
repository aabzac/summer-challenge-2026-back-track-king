package btk.bot.current;

import btk.bot.Bot;
import btk.bot.Params;
import btk.bot.Timer;
import btk.core.Action;
import btk.core.GameState;
import btk.core.Pathing;
import btk.core.Rules;

import java.util.ArrayList;
import java.util.List;

/**
 * v05: v04 with a build cutoff reserving time for sabotage on the original turn clock.
 *
 * <p>Build: for every desired pair generate up to two candidate routes (cheapest path using any
 * tracks; cheapest path avoiding opponent tracks = ownership steal). Each candidate is scored by
 * placing its free cells in a scratch state, recomputing connections and comparing both players'
 * income per turn, projected over the turns left after completion, discounted by build time and
 * by region instability along the route. Paint goes to the best candidate; leftovers cascade.
 * When no complete route improves the evaluation, remaining paint extends existing rails through
 * stable nearby cells, preferring permanent-safe town regions.
 *
 * <p>Opponent model: the same candidate search is run from the opponent's point of view first.
 * Cells they are predicted to place this turn get a routing surcharge (a clash makes the track
 * neutral for both) and are placed last; their predicted route counts as future tracks when
 * choosing what to ink.
 *
 * <p>Disrupt: every non-town, non-inked region is scored by simulating its ink (income lost by the
 * opponent minus our own, plus not-yet-earning tracks destroyed), divided by the disrupts still
 * needed. Best positive region gets the free DISRUPT; failing that, the region with the best
 * opponent-vs-own track balance.
 */
public final class EvalBot implements Bot {

    private static final int MAX_BUILD_BEAM = 4;
    private static final int MAX_OPP_REPLIES = 2;
    private static final int OWN_BEAM_RESERVE_MS = 14;
    private static final int OPP_BEAM_RESERVE_MS = 10;
    private static final int OPP_DISRUPT_RESERVE_MS = 8;

    private final Params P;
    private final Timer timer = new Timer();
    private Pathing pathing;
    private GameState sim, sim2;
    private int[] pathBuf, bestPath, extraCost, oppPath;
    private int[] oppTracks, myTracks;
    private double[] oppRouteByRegion, myPlanByRegion;
    private int[][] buildBeamPath, replyBeamPath, buildBeamPrefix, replyBeamPrefix;
    private int[] buildBeamLen, buildBeamCost, buildBeamMaxInst, buildBeamPrefixLen;
    private int[] replyBeamLen, replyBeamCost, replyBeamMaxInst, replyBeamPrefixLen;
    private int[] replyBaselineScoreDiff;
    private int[] replyDisrupt;
    private double[] buildBeamValue, replyBeamValue, replyBaselineValue;
    private int[] prefixBuf;
    private boolean[] blocked, contested, myRoute, regionMark;
    private final int[] inc0 = new int[2], inc1 = new int[2], incA = new int[2], incB = new int[2];
    private int bestLen, bestCost, oppLen, worstRegion;
    private boolean disruptSearchComplete;
    private boolean[] defenseTried;
    private GameState[] ownPlanStates;
    private int[][] ownPlanCells, ownPlanFirstCells;
    private int[] ownPlanFirstLen;
    private boolean[][] ownPlanRoutes;
    boolean ownPlanCommitted;
    int ownPlanNodes, ownPlanLeaves, ownPlanSelected = -1;
    double ownPlanValue;
    int defensePathQueries, defenseRegionsScanned, defenseSelectedRegion = -1, defenseSelectedTurns;
    private GameState replyState, completionState;
    private GameState jointState;
    private int[] jointTargets, jointPrefixTargets;
    private boolean jointTargetScan;
    // -2 = normal play/fallback; -1 = a committed pair explicitly choosing no sabotage.
    private int jointSelectedTarget = -2, jointBuildSelected = -1, jointPairsEvaluated;
    private boolean jointSearchComplete;
    private java.util.Random rnd;
    /** Inclusive phase counters; evaluation time is a subset of build time, not additive. */
    public long profileBuildNs, profileEvalNs, profileEvalMaxNs, profileDisruptNs;
    public int profileEvalCalls, profileLifetimeBuildCalls;
    public int profileAbortedEvals;

    public EvalBot() {
        this(new Params());
    }

    public EvalBot(Params params) {
        if (!Double.isFinite(params.DISRUPT_DELAY_FACTOR)
                || params.DISRUPT_DELAY_FACTOR < 0 || params.DISRUPT_DELAY_FACTOR > 1) {
            throw new IllegalArgumentException("DISRUPT_DELAY_FACTOR must be in [0,1]");
        }
        if (params.INTERRUPT_VULN_EVAL && params.USE_REPLY_RERANK) {
            throw new IllegalArgumentException("Interrupted eval is not supported by reply reranking");
        }
        if (params.USE_JOINT_ACTION && (!params.USE_REPLY_RERANK || !params.USE_DISRUPT
                || params.BUILD_BEAM_WIDTH != 2 || params.OPP_REPLY_WIDTH != 1
                || params.USE_OPP_MODEL || params.CHOOSE_BUILD_DIRECTION || params.GUARD_BUILD_INCOME
                || params.EARLY_DISRUPT_FALLBACK || params.INTERRUPT_VULN_EVAL)) {
            throw new IllegalArgumentException("Joint action requires plain K2/R1 + sabotage, other experiments off");
        }
        this.P = params;
        if (params.USE_OWN_BUILD_PLAN && (params.OWN_BUILD_WIDTH < 1 || params.OWN_BUILD_WIDTH > 3
                || params.OWN_BUILD_DEPTH < 2 || params.OWN_BUILD_DEPTH > 3
                || params.USE_DEFENSE_PRIORITY || params.USE_REPLY_RERANK || params.USE_JOINT_ACTION
                || params.USE_HEURISTIC_POLICY || params.USE_OPP_MODEL || params.CHOOSE_BUILD_DIRECTION
                || params.GUARD_BUILD_INCOME || params.EARLY_DISRUPT_FALLBACK || params.INTERRUPT_VULN_EVAL)) {
            throw new IllegalArgumentException("Own build plan requires plain construction, width 1..3, depth 2..3");
        }
        if (params.USE_DEFENSE_PRIORITY && (params.USE_REPLY_RERANK || params.CHOOSE_BUILD_DIRECTION
                || params.USE_HEURISTIC_POLICY || params.DEFENSE_MAX_REGIONS < 1
                || params.DEFENSE_MAX_REGIONS > 3 || params.DEFENSE_MAX_PAIRS < 1
                || params.DEFENSE_MAX_PAIRS > 4 || params.DEFENSE_MAX_PAINT < 1
                || params.DEFENSE_MAX_PAINT > 6 || params.DEFENSE_MIN_INSTABILITY < 1
                || params.DEFENSE_MIN_INSTABILITY >= GameState.INK_THRESHOLD)) {
            throw new IllegalArgumentException("Defense requires plain construction and bounded positive limits");
        }
    }

    @Override
    public String name() {
        String d = P.diff();
        return d.isEmpty() ? "current" : "current?" + d;
    }

    @Override
    public void init(GameState s, int myId) {
        ensureBuffers(s);
        rnd = new java.util.Random(P.SEED * 1_000_003L + myId * 7919L);
    }

    private double noise() {
        if (P.NOISE <= 0) return 1.0;
        if (rnd == null) rnd = new java.util.Random(P.SEED);
        return 1.0 + P.NOISE * (rnd.nextDouble() - 0.5);
    }

    private void ensureBuffers(GameState s) {
        if (pathing == null || pathBuf == null || pathBuf.length != s.size) {
            pathing = new Pathing(s.size);
            pathBuf = new int[s.size];
            bestPath = new int[s.size];
            oppPath = new int[s.size];
            extraCost = new int[s.size];
            blocked = new boolean[s.size];
            contested = new boolean[s.size];
            myRoute = new boolean[s.size];
            regionMark = new boolean[s.regionCount];
            oppTracks = new int[s.regionCount];
            myTracks = new int[s.regionCount];
            oppRouteByRegion = new double[s.regionCount];
            myPlanByRegion = new double[s.regionCount];
            buildBeamPath = new int[MAX_BUILD_BEAM][s.size];
            replyBeamPath = new int[MAX_OPP_REPLIES][s.size];
            buildBeamPrefix = new int[MAX_BUILD_BEAM][GameState.PAINT_PER_TURN];
            replyBeamPrefix = new int[MAX_OPP_REPLIES][GameState.PAINT_PER_TURN];
            buildBeamLen = new int[MAX_BUILD_BEAM];
            buildBeamCost = new int[MAX_BUILD_BEAM];
            buildBeamMaxInst = new int[MAX_BUILD_BEAM];
            buildBeamPrefixLen = new int[MAX_BUILD_BEAM];
            replyBeamLen = new int[MAX_OPP_REPLIES];
            replyBeamCost = new int[MAX_OPP_REPLIES];
            replyBeamMaxInst = new int[MAX_OPP_REPLIES];
            replyBeamPrefixLen = new int[MAX_OPP_REPLIES];
            replyBaselineScoreDiff = new int[MAX_OPP_REPLIES];
            replyDisrupt = new int[MAX_OPP_REPLIES];
            buildBeamValue = new double[MAX_BUILD_BEAM];
            replyBeamValue = new double[MAX_OPP_REPLIES];
            replyBaselineValue = new double[MAX_OPP_REPLIES];
            prefixBuf = new int[GameState.PAINT_PER_TURN];
            sim = s.copy();
            sim2 = s.copy();
            replyState = s.copy();
            completionState = s.copy();
            if (P.USE_JOINT_ACTION) {
                jointState = s.copy();
                jointTargets = new int[4];
                jointPrefixTargets = new int[2];
            }
            if (P.USE_DEFENSE_PRIORITY) defenseTried = new boolean[s.regionCount];
            if (P.USE_OWN_BUILD_PLAN) {
                ownPlanStates = new GameState[3];
                for (int i = 0; i < 3; i++) ownPlanStates[i] = s.copy();
                ownPlanCells = new int[3][GameState.PAINT_PER_TURN];
                ownPlanFirstCells = new int[3][GameState.PAINT_PER_TURN];
                ownPlanFirstLen = new int[3];
                ownPlanRoutes = new boolean[3][s.size];
            }
        }
    }

    /**
     * Value of a state for {@code me}: income difference now, minus the damage of the opponent's
     * most profitable single ink (regions on active paths that hold my tracks), discounted by the
     * disrupts it still needs. Sets {@link #worstRegion} to that region (-1 if none).
     */
    private double evalState(GameState st, int me) {
        if (!P.PROFILE_SEARCH) return evalStateImpl(st, me);
        long started = System.nanoTime();
        try {
            return evalStateImpl(st, me);
        } finally {
            long elapsed = System.nanoTime() - started;
            profileEvalNs += elapsed;
            profileEvalMaxNs = Math.max(profileEvalMaxNs, elapsed);
            profileEvalCalls++;
        }
    }

    private double evalStateImpl(GameState st, int me) {
        if (abortEvaluation()) return Double.NaN;
        int opp = 1 - me;
        Rules.incomePerTurn(st, incA);
        double imm = incA[me] - P.W_OPP_INCOME * incA[opp];
        worstRegion = -1;
        if (P.W_VULN <= 0) return imm;
        java.util.Arrays.fill(regionMark, false);
        for (int p = 0; p < st.pairCount; p++) {
            if (!st.pairActive(p)) continue;
            int[] path = st.pairPath[p];
            for (int i = 0; i < st.pairPathLen[p]; i++) {
                int c = path[i];
                if (st.owner[c] == me) regionMark[st.regionId[c]] = true;
            }
        }
        double worst = 0;
        for (int r = 0; r < st.regionCount; r++) {
            if (!regionMark[r] || st.regionInked[r] || st.regionHasTown(r)) continue;
            if (abortEvaluation()) return Double.NaN;
            int needed = Math.max(1, GameState.INK_THRESHOLD - st.regionInstability[r]);
            sim2.copyFrom(st);
            Rules.ink(sim2, r);
            Rules.updateConnections(sim2, pathing);
            Rules.incomePerTurn(sim2, incB);
            double myLoss = incA[me] - incB[me];
            double theirLoss = incA[opp] - incB[opp];
            double threat = (myLoss - P.W_THEIR_LOSS * theirLoss) / needed;
            if (threat > worst) {
                worst = threat;
                worstRegion = r;
            }
        }
        return imm - P.W_VULN * worst;
    }

    private boolean abortEvaluation() {
        if (!P.INTERRUPT_VULN_EVAL || !buildTimeUp()) return false;
        worstRegion = -1;
        if (P.PROFILE_SEARCH) profileAbortedEvals++;
        return true;
    }

    @Override
    public List<Action> play(GameState s, int myId, long budgetMs) {
        timer.start(budgetMs);
        defensePathQueries = defenseRegionsScanned = defenseSelectedTurns = 0;
        defenseSelectedRegion = -1;
        ownPlanCommitted = false; ownPlanNodes = ownPlanLeaves = 0; ownPlanSelected = -1;
        ownPlanValue = Double.NaN;
        jointSelectedTarget = -2; jointBuildSelected = -1; jointPairsEvaluated = 0; jointSearchComplete = false;
        if (P.PROFILE_SEARCH) {
            profileBuildNs = profileEvalNs = profileEvalMaxNs = profileDisruptNs = 0;
            profileEvalCalls = 0;
            profileAbortedEvals = 0;
        }
        ensureBuffers(s);
        int opp = 1 - myId;
        List<Action> out = new ArrayList<>(4);
        for (int c = 0; c < s.size; c++) {
            extraCost[c] = (int) Math.round(P.UNSTABLE_COST * s.regionInstability[s.regionId[c]]);
            contested[c] = false;
            myRoute[c] = false;
        }

        // --- opponent prediction (their best route with our algorithm, no collision penalty) ---
        oppLen = 0;
        if (P.USE_OPP_MODEL && chooseCandidate(s, opp, GameState.PAINT_PER_TURN)) {
            oppLen = bestLen;
            System.arraycopy(bestPath, 0, oppPath, 0, oppLen);
            int paint = 0;
            for (int i = 0; i < oppLen && paint < GameState.PAINT_PER_TURN; i++) {
                int c = oppPath[i];
                if (!s.canBuild(c)) continue;
                paint += s.placeCost(c);
                if (paint <= GameState.PAINT_PER_TURN) {
                    contested[c] = true;
                    extraCost[c] += (int) Math.round(P.COLLISION_COST);
                }
            }
        }

        // A cheap, deterministic fallback is saved before route search can consume the turn.
        // Only regions that one DISRUPT can ink are considered; normal post-build selection below
        // remains authoritative whenever it completes.
        int earlyDisrupt = P.USE_DISRUPT && P.EARLY_DISRUPT_FALLBACK
                ? chooseEarlyDisrupt(s, myId) : -1;

        // --- build ---
        int budget = GameState.PAINT_PER_TURN;
        int guard = 0;
        boolean builtAny = false;
        boolean replyRerankPending = P.USE_REPLY_RERANK;
        boolean defensePending = P.USE_DEFENSE_PRIORITY;
        boolean ownPlanPending = P.USE_OWN_BUILD_PLAN;
        while (budget > 0 && guard++ < 6 && !buildTimeUp()) {
            boolean found = ownPlanPending && chooseOwnBuildPlan(s, myId, budget);
            ownPlanPending = false;
            if (!found) found = defensePending && chooseDefenseCandidate(s, myId, budget);
            defensePending = false;
            if (!found) found = replyRerankPending
                    ? chooseCandidateWithReplies(s, myId, budget)
                    : chooseCandidate(s, myId, budget);
            replyRerankPending = false;
            if (!found) break;
            int before = budget;
            // Keep the selected long-term route; only compare the cells affordable this turn.
            // Complete routes have identical resulting ownership in either direction.
            boolean reverse = P.CHOOSE_BUILD_DIRECTION && bestCost > budget && !buildTimeUp()
                    && preferReverseBuild(s, myId, budget, bestPath, bestLen);
            for (int i = 0; i < bestLen; i++) if (s.canBuild(bestPath[i])) myRoute[bestPath[i]] = true;
            // uncontested cells first, then contested ones if paint is left
            for (int pass = 0; pass < 2 && budget > 0; pass++) {
                for (int i = 0; i < bestLen && budget > 0; i++) {
                    int c = bestPath[reverse ? bestLen - 1 - i : i];
                    if (!s.canBuild(c) || contested[c] != (pass == 1)) continue;
                    int cost = s.placeCost(c);
                    if (cost > budget) continue;
                    budget -= cost;
                    out.add(Action.place(s.x(c), s.y(c)));
                    s.owner[c] = myId;
                    builtAny = true;
                }
            }
            if (budget == before) break;
            Rules.updateConnections(s, pathing);
            if (jointSelectedTarget >= -1 || ownPlanCommitted) break; // emit exactly the evaluated prefix
        }

        // Keep useful local momentum when every complete route has zero immediate evaluation
        // gain. Prefer cells adjoining our network, especially in permanent-safe town regions.
        if (P.USE_IDLE_EXTEND && jointSelectedTarget == -2 && !ownPlanCommitted) {
            boolean extended = false;
            while (budget > 0 && !buildTimeUp()) {
                int c = chooseIdleExtension(s, myId, budget);
                if (c < 0) break;
                budget -= s.placeCost(c);
                myRoute[c] = true;
                out.add(Action.place(s.x(c), s.y(c)));
                s.owner[c] = myId;
                builtAny = true;
                extended = true;
            }
            if (extended) Rules.updateConnections(s, pathing);
        }

        // --- disrupt ---
        if (jointSelectedTarget >= -1) {
            if (jointSelectedTarget >= 0) out.add(Action.disrupt(jointSelectedTarget));
        } else if (P.USE_DISRUPT) {
            int safeEarly = earlyDisrupt;
            if (safeEarly >= 0 && builtAny && !earlyDisruptStillGood(s, myId, safeEarly)) safeEarly = -1;
            int region = chooseDisrupt(s, myId);
            if (region < 0 && !disruptSearchComplete) region = safeEarly;
            if (region >= 0) out.add(Action.disrupt(region));
        }
        if (P.MESSAGE) out.add(Action.message("t" + s.turn + " " + timer.elapsedMs() + "ms"));
        if (out.isEmpty()) out.add(Action.waitAction());
        return out;
    }

    // ------------------------------------------------------------------ build

    /** Old route pool, new bounded sequences of affordable actions. No speculative enemy moves. */
    private boolean chooseOwnBuildPlan(GameState s, int me, int budgetNow) {
        long started = P.PROFILE_SEARCH ? System.nanoTime() : 0;
        try {
            int count = collectCandidates(s, me, budgetNow, P.OWN_BUILD_WIDTH,
                    P.USE_DISRUPT ? P.DISRUPT_RESERVE_MS : 0, true,
                    buildBeamPath, buildBeamLen, buildBeamCost, buildBeamMaxInst,
                    buildBeamPrefix, buildBeamPrefixLen, buildBeamValue);
            if (count == 0) return false;
            copyBuildCandidateToBest(0); // legal ordinary route fallback, even after an interrupted search
            rankOwnBuildPlans(s, me, count);
            return true;
        } finally {
            if (P.PROFILE_SEARCH) {
                profileBuildNs += System.nanoTime() - started;
                profileLifetimeBuildCalls++;
            }
        }
    }

    /** Commit only after every distinct first action has complete, equal-depth coverage. */
    private void rankOwnBuildPlans(GameState s, int me, int count) {
        int depth = Math.min(P.OWN_BUILD_DEPTH, s.turnsLeft());
        if (depth <= 0) return;
        java.util.Arrays.fill(ownPlanFirstLen, -1);
        int selected = -1;
        double best = Double.NEGATIVE_INFINITY;
        for (int first = 0; first < count; first++) {
            if (buildTimeUp()) return;
            java.util.Arrays.fill(ownPlanRoutes[first], false);
            int n = simulateOwnBuild(s, me, first, count, 0, ownPlanRoutes[first]);
            System.arraycopy(ownPlanCells[0], 0, ownPlanFirstCells[first], 0, n);
            ownPlanFirstLen[first] = n;
            boolean duplicate = false;
            for (int i = 0; i < first; i++) {
                if (samePlacementSet(ownPlanFirstCells[i], ownPlanFirstLen[i], ownPlanCells[0], n)) {
                    duplicate = true; break;
                }
            }
            if (duplicate) continue;
            double value = ownBuildContinuation(ownPlanStates[0], me, count, 1, depth);
            if (Double.isNaN(value) || buildTimeUp()) return;
            if (value > best) { best = value; selected = first; }
        }
        if (selected < 0 || buildTimeUp()) return;
        ownPlanCommitted = true;
        ownPlanSelected = selected;
        ownPlanValue = best - (s.score[me] - s.score[1 - me]);
        bestLen = ownPlanFirstLen[selected]; bestCost = 0;
        System.arraycopy(ownPlanFirstCells[selected], 0, bestPath, 0, bestLen);
        for (int i = 0; i < bestLen; i++) bestCost += s.placeCost(bestPath[i]);
        System.arraycopy(ownPlanRoutes[selected], 0, myRoute, 0, s.size);
    }

    /** At most 3 + 9 + 27 nodes. NaN discards all partial comparisons, not just this branch. */
    private double ownBuildContinuation(GameState s, int me, int count, int level, int depth) {
        if (buildTimeUp()) return Double.NaN;
        if (level == depth) {
            ownPlanLeaves++;
            int remaining = Math.max(0, Math.min(s.turnsLeft(), P.HORIZON - depth));
            double terminal = remaining > 0 ? evalState(s, me) * remaining : 0;
            return buildTimeUp() ? Double.NaN : s.score[me] - s.score[1 - me] + terminal;
        }
        double best = Double.NEGATIVE_INFINITY;
        for (int first = 0; first < count; first++) {
            if (buildTimeUp()) return Double.NaN;
            simulateOwnBuild(s, me, first, count, level, null);
            double value = ownBuildContinuation(ownPlanStates[level], me, count, level + 1, depth);
            if (Double.isNaN(value)) return value;
            if (value > best) best = value;
        }
        return best;
    }

    /** Fill one turn's paint from the priority route, then other pool routes in stable order. */
    private int simulateOwnBuild(GameState before, int me, int first, int count, int level,
                                 boolean[] routeMask) {
        GameState next = ownPlanStates[level];
        next.copyFrom(before);
        int budget = GameState.PAINT_PER_TURN, total = 0;
        for (int slot = -1; slot < count && budget > 0; slot++) {
            int project = slot < 0 ? first : slot;
            if (slot == first) continue;
            int n = fillAffordablePrefix(next, budget, buildBeamPath[project], buildBeamLen[project], prefixBuf);
            if (n == 0) continue;
            if (routeMask != null) {
                for (int i = 0; i < buildBeamLen[project]; i++) {
                    int c = buildBeamPath[project][i];
                    if (next.canBuild(c)) routeMask[c] = true;
                }
            }
            for (int i = 0; i < n; i++) {
                int c = prefixBuf[i];
                budget -= next.placeCost(c);
                ownPlanCells[level][total++] = c;
            }
            Rules.applyPlacements(next, prefixBuf, me == 0 ? n : 0, prefixBuf, me == 1 ? n : 0);
        }
        Rules.updateConnections(next, pathing);
        Rules.scoreTurn(next, null);
        next.turn++;
        ownPlanNodes++;
        return total;
    }

    private static boolean samePlacementSet(int[] a, int an, int[] b, int bn) {
        if (an != bn) return false;
        for (int i = 0; i < an; i++) {
            boolean found = false;
            for (int j = 0; j < bn; j++) if (a[i] == b[j]) { found = true; break; }
            if (!found) return false;
        }
        return true;
    }

    /** Known-state defense only: bounded path work, core income, no same-turn enemy actions. */
    private boolean chooseDefenseCandidate(GameState s, int me, int budgetNow) {
        java.util.Arrays.fill(regionMark, false);
        java.util.Arrays.fill(defenseTried, false);
        for (int p = 0; p < s.pairCount; p++) if (s.pairActive(p)) {
            for (int i = 0; i < s.pairPathLen[p]; i++) {
                int c = s.pairPath[p][i], r = s.regionId[c];
                if (s.owner[c] == me && s.regionInstability[r] >= P.DEFENSE_MIN_INSTABILITY
                        && !s.regionInked[r] && !s.regionHasTown(r)) regionMark[r] = true;
            }
        }
        Rules.incomePerTurn(s, inc0);
        int beforeMine = inc0[me], beforeDiff = inc0[me] - inc0[1 - me];
        double best = 0;
        bestLen = -1;
        for (int scan = 0; scan < P.DEFENSE_MAX_REGIONS && !buildTimeUp(); scan++) {
            int region = -1;
            for (int r = 0; r < s.regionCount; r++) if (regionMark[r] && !defenseTried[r]
                    && (region < 0 || s.regionInstability[r] > s.regionInstability[region])) region = r;
            if (region < 0) break;
            defenseTried[region] = true; defenseRegionsScanned++;
            int hits = GameState.INK_THRESHOLD - s.regionInstability[region];
            int deadline = Math.min(hits, s.turnsLeft());
            if (deadline <= 0) continue;
            sim2.copyFrom(s);
            Rules.ink(sim2, region);
            Rules.updateConnections(sim2, pathing);
            Rules.incomePerTurn(sim2, incB);
            int inkMine = incB[me], inkDiff = incB[me] - incB[1 - me];
            if (inkMine >= beforeMine) continue;
            for (int c = 0; c < s.size; c++) blocked[c] = s.regionId[c] == region
                    || (s.regionInstability[s.regionId[c]] > 0 && !s.regionHasTown(s.regionId[c]));
            int tried = 0;
            for (int p = 0; p < s.pairCount && tried < P.DEFENSE_MAX_PAIRS && !buildTimeUp(); p++) {
                if (!s.pairActive(p)) continue;
                boolean crosses = false, mine = false;
                for (int i = 0; i < s.pairPathLen[p]; i++) {
                    int c = s.pairPath[p][i];
                    if (s.regionId[c] == region) crosses = true;
                    if (s.owner[c] == me) mine = true;
                }
                if (!crosses || !mine) continue;
                tried++; defensePathQueries++;
                int to = s.townCell[s.pairTo[p]];
                int n = pathing.cheapestPath(s, s.townCell[s.pairFrom[p]], to, pathBuf, blocked);
                if (n < 0) continue;
                int paint = pathing.lastCost(to);
                if (paint <= 0 || paint > P.DEFENSE_MAX_PAINT) continue;
                int turns = prepareDefenseCompletion(s, me, budgetNow, n, deadline, beforeDiff);
                if (turns < 0 || buildTimeUp()) continue;
                // sim now contains only our completed placements, checked prefix-by-prefix.
                Rules.ink(sim, region);
                Rules.updateConnections(sim, pathing);
                Rules.incomePerTurn(sim, incA);
                int recovery = incA[me] - incA[1 - me] - inkDiff;
                if (incA[me] <= inkMine || recovery <= 0 || buildTimeUp()) continue;
                double value = (double) recovery / (paint * hits);
                if (value > best) {
                    best = value; bestLen = n; bestCost = paint;
                    defenseSelectedRegion = region; defenseSelectedTurns = turns;
                    System.arraycopy(pathBuf, 0, bestPath, 0, n);
                }
            }
        }
        return bestLen > 0;
    }

    /** Same affordable ordering as emission. Total paint alone misses per-turn packing waste. */
    private int prepareDefenseCompletion(GameState s, int me, int budgetNow, int len,
                                         int deadline, int beforeDiff) {
        sim.copyFrom(s);
        for (int turn = 1; turn <= deadline && !buildTimeUp(); turn++) {
            int budget = turn == 1 ? budgetNow : GameState.PAINT_PER_TURN, count = 0;
            for (int pass = 0; pass < 2; pass++) for (int i = 0; i < len; i++) {
                int c = pathBuf[i];
                if (!sim.canBuild(c) || contested[c] != (pass == 1)) continue;
                int cost = sim.placeCost(c);
                if (cost > budget) continue;
                boolean duplicate = false;
                for (int j = 0; j < count; j++) if (prefixBuf[j] == c) duplicate = true;
                if (duplicate) continue;
                budget -= cost;
                prefixBuf[count++] = c;
            }
            if (count == 0) return -1;
            Rules.applyPlacements(sim, prefixBuf, me == 0 ? count : 0, prefixBuf, me == 1 ? count : 0);
            Rules.updateConnections(sim, pathing);
            Rules.incomePerTurn(sim, incA);
            if (incA[me] - incA[1 - me] < beforeDiff) return -1;
            boolean complete = true;
            for (int i = 0; i < len; i++) if (sim.canBuild(pathBuf[i])) { complete = false; break; }
            if (complete) return turn;
        }
        return -1;
    }

    /** A phase cutoff, not a new timer: sabotage still uses the original turn deadline. */
    private boolean buildTimeUp() {
        return P.USE_DISRUPT && P.DISRUPT_RESERVE_MS > 0
                ? timer.up(P.DISRUPT_RESERVE_MS) : timer.up();
    }

    /** Fills bestPath/bestLen/bestCost with the best candidate for {@code me}; false when nothing is worth building. */
    private boolean chooseCandidate(GameState s, int me, int budgetNow) {
        if (!P.PROFILE_SEARCH) return chooseCandidateImpl(s, me, budgetNow);
        long started = System.nanoTime();
        profileLifetimeBuildCalls++;
        try {
            return chooseCandidateImpl(s, me, budgetNow);
        } finally {
            profileBuildNs += System.nanoTime() - started;
        }
    }

    private boolean chooseCandidateImpl(GameState s, int me, int budgetNow) {
        if (P.USE_DISRUPT && P.DISRUPT_RESERVE_MS > 0 && buildTimeUp()) return false;
        double base = evalState(s, me);
        int threatened = worstRegion;
        double bestValue = 1e-9;
        if (!Double.isFinite(base)) return false;
        bestLen = -1;
        int opp = 1 - me;
        for (int c = 0; c < s.size; c++) blocked[c] = s.owner[c] == opp;
        int turnsLeft = s.turnsLeft();
        for (int p = 0; p < s.pairCount && !buildTimeUp(); p++) {
            int from = s.townCell[s.pairFrom[p]], to = s.townCell[s.pairTo[p]];
            for (int variant = 0; variant < 3 && !buildTimeUp(); variant++) {
                if (variant == 1 && !P.USE_STEAL) continue;
                boolean[] blk = null;
                if (variant == 1) {
                    blk = blocked;
                } else if (variant == 2) {
                    // backup route: active pair whose path crosses the most threatened region
                    if (!P.USE_BACKUP || threatened < 0 || !s.pairActive(p)) break;
                    boolean crosses = false;
                    for (int i = 0; i < s.pairPathLen[p] && !crosses; i++) crosses = s.regionId[s.pairPath[p][i]] == threatened;
                    if (!crosses) break;
                    for (int c = 0; c < s.size; c++) blocked[c] = s.regionId[c] == threatened;
                    blk = blocked;
                }
                int n = pathing.cheapestPath(s, from, to, pathBuf, blk, extraCost);
                if (variant == 2) for (int c = 0; c < s.size; c++) blocked[c] = s.owner[c] == opp;
                if (n < 0) continue;
                int paint = 0, maxInst = 0;
                for (int i = 0; i < n; i++) {
                    int c = pathBuf[i];
                    if (s.canBuild(c)) {
                        paint += s.placeCost(c);
                        maxInst = Math.max(maxInst, s.regionInstability[s.regionId[c]]);
                    }
                }
                if (paint == 0) continue;
                if (variant != 2 && s.pairActive(p) && n > s.pairPathLen[p]) continue;
                int remaining = Math.max(0, paint - budgetNow);
                int turnsToFinish = (remaining + GameState.PAINT_PER_TURN - 1) / GameState.PAINT_PER_TURN;
                int earning = Math.min(turnsLeft, P.HORIZON) - turnsToFinish;
                if (earning <= 0) continue;

                sim.copyFrom(s);
                for (int i = 0; i < n; i++) {
                    int c = pathBuf[i];
                    if (sim.canBuild(c)) sim.owner[c] = me;
                }
                Rules.updateConnections(sim, pathing);
                double gain = evalState(sim, me) - base;
                if (gain <= 1e-9) continue;
                double risk = Math.max(0, 1 - P.W_RISK * maxInst / GameState.INK_THRESHOLD);
                double value = gain * earning * risk - P.W_COST * paint;
                if (!Double.isFinite(gain)) break; // incomplete evaluations cannot replace bestPath
                value /= (turnsToFinish + 1);
                value *= noise();
                if (value > bestValue) {
                    if (P.GUARD_BUILD_INCOME && !buildPrefixNonLosing(s, me, budgetNow, n)) continue;
                    bestValue = value;
                    bestLen = n;
                    bestCost = paint;
                    System.arraycopy(pathBuf, 0, bestPath, 0, n);
                }
            }
        }
        return bestLen > 0;
    }

    /** Keeps several strong prefixes, then reranks them against likely simultaneous replies. */
    private boolean chooseCandidateWithReplies(GameState s, int me, int budgetNow) {
        int buildLimit = Math.max(1, Math.min(MAX_BUILD_BEAM, P.BUILD_BEAM_WIDTH));
        int buildCount = collectCandidates(s, me, budgetNow, buildLimit, OWN_BEAM_RESERVE_MS, true,
                buildBeamPath, buildBeamLen, buildBeamCost, buildBeamMaxInst,
                buildBeamPrefix, buildBeamPrefixLen, buildBeamValue);
        if (buildCount == 0) return false;
        copyBuildCandidateToBest(0);
        if (timer.up(OPP_BEAM_RESERVE_MS)) return true;

        int replyLimit = Math.max(1, Math.min(MAX_OPP_REPLIES, P.OPP_REPLY_WIDTH));
        int opp = 1 - me;
        int replyCount = collectCandidates(s, opp, GameState.PAINT_PER_TURN, replyLimit,
                OPP_BEAM_RESERVE_MS, false, replyBeamPath, replyBeamLen, replyBeamCost,
                replyBeamMaxInst, replyBeamPrefix, replyBeamPrefixLen, replyBeamValue);
        if (replyCount == 0) {
            replyBeamLen[0] = 0;
            replyBeamPrefixLen[0] = 0;
            replyCount = 1;
        } else if (replyCount < replyLimit) {
            // Keep a no-build alternative when only one plausible route survived the filter.
            replyBeamLen[replyCount] = 0;
            replyBeamPrefixLen[replyCount] = 0;
            replyCount++;
        }
        for (int j = 0; j < replyCount; j++) {
            replyDisrupt[j] = predictDisrupt(s, opp, replyBeamPath[j], replyBeamLen[j],
                    OPP_DISRUPT_RESERVE_MS);
        }

        int usableReplies = 0;
        for (int j = 0; j < replyCount && !buildTimeUp(); j++) {
            simulatePredictedTurn(s, me, null, 0, replyBeamPrefix[j], replyBeamPrefixLen[j],
                    replyDisrupt[j], replyState);
            replyBaselineValue[j] = evalState(replyState, me);
            replyBaselineScoreDiff[j] = replyState.score[me] - replyState.score[opp];
            usableReplies++;
        }
        if (usableReplies == 0) return true;

        int selected = 0;
        double selectedWorst = Double.NEGATIVE_INFINITY;
        boolean evaluatedAny = false;
        for (int i = 0; i < buildCount && !buildTimeUp(); i++) {
            double worst = Double.POSITIVE_INFINITY;
            int evaluated = 0;
            for (int j = 0; j < usableReplies && !buildTimeUp(); j++) {
                double value = replyAwareValue(s, me, i, j, replyDisrupt[j]);
                if (value < worst) worst = value;
                evaluated++;
            }
            if (evaluated != usableReplies) break;
            if (!evaluatedAny || worst > selectedWorst) {
                evaluatedAny = true;
                selectedWorst = worst;
                selected = i;
            }
        }
        if (evaluatedAny) copyBuildCandidateToBest(selected);
        if (P.USE_JOINT_ACTION && evaluatedAny && usableReplies == replyCount && !buildTimeUp()) {
            chooseJointAction(s, me, buildCount, usableReplies, selected);
        }
        return true;
    }

    /** Small cross product; targets use only known state. No allocations per pair. */
    private void chooseJointAction(GameState s, int me, int count, int replies, int original) {
        if (buildTimeUp()) return;
        int targets = 0;
        jointTargets[targets++] = -1;
        int common = jointTarget(s, me, -1);
        if (!disruptSearchComplete || buildTimeUp()) return;
        targets = addJointTarget(targets, common);
        for (int i = 0; i < count; i++) {
            jointPrefixTargets[i] = jointTarget(s, me, i);
            if (!disruptSearchComplete || buildTimeUp()) return;
            targets = addJointTarget(targets, jointPrefixTargets[i]);
        }
        double best = jointPairValue(s, me, original, jointPrefixTargets[original], replies);
        if (Double.isNaN(best)) return;
        int selected = original, target = jointPrefixTargets[original];
        double baseline = best;
        for (int i = 0; i < count; i++) {
            for (int t = 0; t < targets; t++) {
                if (i == original && jointTargets[t] == jointPrefixTargets[original]) continue;
                double value = jointPairValue(s, me, i, jointTargets[t], replies);
                if (Double.isNaN(value)) {
                    commitJointIfBetter(selected, target, best, baseline);
                    return;
                }
                if (value > best + 1e-9) { best = value; selected = i; target = jointTargets[t]; }
            }
        }
        jointSearchComplete = true;
        commitJointIfBetter(selected, target, best, baseline);
    }

    private void commitJointIfBetter(int selected, int target, double value, double baseline) {
        if (!(value > baseline + 1e-9)) return;
        copyBuildCandidateToBest(selected);
        jointBuildSelected = selected;
        jointSelectedTarget = target;
    }

    private int addJointTarget(int count, int target) {
        for (int i = 0; i < count; i++) if (jointTargets[i] == target) return count;
        jointTargets[count] = target;
        return count + 1;
    }

    private int jointTarget(GameState s, int me, int build) {
        jointState.copyFrom(s);
        java.util.Arrays.fill(myRoute, false);
        if (build >= 0) {
            for (int i = 0; i < buildBeamLen[build]; i++) {
                int c = buildBeamPath[build][i];
                if (s.canBuild(c)) myRoute[c] = true;
            }
            int[] cells = buildBeamPrefix[build]; int n = buildBeamPrefixLen[build];
            Rules.applyPlacements(jointState, me == 0 ? cells : prefixBuf, me == 0 ? n : 0,
                    me == 1 ? cells : prefixBuf, me == 1 ? n : 0);
            Rules.updateConnections(jointState, pathing);
        }
        double noise = P.NOISE;
        P.NOISE = 0; jointTargetScan = true;
        try { return chooseDisrupt(jointState, me); }
        finally { P.NOISE = noise; jointTargetScan = false; java.util.Arrays.fill(myRoute, false); }
    }

    private double jointPairValue(GameState s, int me, int build, int ownTarget, int replies) {
        double worst = Double.POSITIVE_INFINITY;
        for (int r = 0; r < replies; r++) {
            if (buildTimeUp()) return Double.NaN;
            double value = replyAwareValue(s, me, build, r, replyDisrupt[r], ownTarget);
            if (buildTimeUp() || Double.isNaN(value)) return Double.NaN;
            if (value < worst) worst = value;
        }
        jointPairsEvaluated++;
        return worst;
    }

    /** Candidate enumeration equivalent to the normal route scorer, retaining distinct prefixes. */
    private int collectCandidates(GameState s, int me, int budgetNow, int limit, int reserveMs,
                                  boolean noisy, int[][] paths, int[] lens, int[] costs,
                                  int[] maxInstability, int[][] prefixes, int[] prefixLens,
                                  double[] values) {
        if (timer.up(reserveMs)) return 0;
        double base = evalState(s, me);
        int threatened = worstRegion;
        int count = 0;
        int opp = 1 - me;
        for (int c = 0; c < s.size; c++) blocked[c] = s.owner[c] == opp;
        int turnsLeft = s.turnsLeft();
        for (int p = 0; p < s.pairCount && !timer.up(reserveMs); p++) {
            int from = s.townCell[s.pairFrom[p]], to = s.townCell[s.pairTo[p]];
            for (int variant = 0; variant < 3 && !timer.up(reserveMs); variant++) {
                if (variant == 1 && !P.USE_STEAL) continue;
                boolean[] blk = null;
                if (variant == 1) {
                    blk = blocked;
                } else if (variant == 2) {
                    if (!P.USE_BACKUP || threatened < 0 || !s.pairActive(p)) break;
                    boolean crosses = false;
                    for (int i = 0; i < s.pairPathLen[p] && !crosses; i++) {
                        crosses = s.regionId[s.pairPath[p][i]] == threatened;
                    }
                    if (!crosses) break;
                    for (int c = 0; c < s.size; c++) blocked[c] = s.regionId[c] == threatened;
                    blk = blocked;
                }
                int n = pathing.cheapestPath(s, from, to, pathBuf, blk, extraCost);
                if (variant == 2) {
                    for (int c = 0; c < s.size; c++) blocked[c] = s.owner[c] == opp;
                }
                if (n < 0) continue;
                int paint = 0, maxInst = 0;
                for (int i = 0; i < n; i++) {
                    int c = pathBuf[i];
                    if (s.canBuild(c)) {
                        paint += s.placeCost(c);
                        maxInst = Math.max(maxInst, s.regionInstability[s.regionId[c]]);
                    }
                }
                if (paint == 0) continue;
                if (variant != 2 && s.pairActive(p) && n > s.pairPathLen[p]) continue;
                int remaining = Math.max(0, paint - budgetNow);
                int turnsToFinish = (remaining + GameState.PAINT_PER_TURN - 1) / GameState.PAINT_PER_TURN;
                int earning = Math.min(turnsLeft, P.HORIZON) - turnsToFinish;
                if (earning <= 0) continue;

                sim.copyFrom(s);
                for (int i = 0; i < n; i++) {
                    int c = pathBuf[i];
                    if (sim.canBuild(c)) sim.owner[c] = me;
                }
                Rules.updateConnections(sim, pathing);
                double gain = evalState(sim, me) - base;
                if (gain <= 1e-9) continue;
                double risk = Math.max(0, 1 - P.W_RISK * maxInst / GameState.INK_THRESHOLD);
                double value = (gain * earning * risk - P.W_COST * paint) / (turnsToFinish + 1);
                if (noisy) value *= noise();
                int prefixLen = fillAffordablePrefix(s, budgetNow, pathBuf, n, prefixBuf);
                if (prefixLen == 0) continue;
                count = insertCandidate(limit, count, value, paint, maxInst, pathBuf, n,
                        prefixBuf, prefixLen, paths, lens, costs, maxInstability,
                        prefixes, prefixLens, values);
            }
        }
        return count;
    }

    private int fillAffordablePrefix(GameState s, int budget, int[] route, int len, int[] out) {
        int count = 0;
        for (int pass = 0; pass < 2 && budget > 0; pass++) {
            for (int i = 0; i < len && budget > 0; i++) {
                int c = route[i];
                if (!s.canBuild(c) || contested[c] != (pass == 1)) continue;
                int cost = s.placeCost(c);
                if (cost > budget) continue;
                budget -= cost;
                out[count++] = c;
            }
        }
        return count;
    }

    private int insertCandidate(int limit, int count, double value, int cost, int maxInst,
                                int[] route, int routeLen, int[] prefix, int prefixLen,
                                int[][] paths, int[] lens, int[] costs, int[] maxInstability,
                                int[][] prefixes, int[] prefixLens, double[] values) {
        for (int i = 0; i < count; i++) {
            if (!samePrefix(prefixes[i], prefixLens[i], prefix, prefixLen)) continue;
            if (value <= values[i]) return count;
            for (int j = i; j + 1 < count; j++) {
                copyCandidateSlot(j + 1, j, paths, lens, costs, maxInstability,
                        prefixes, prefixLens, values);
            }
            count--;
            break;
        }
        int position = 0;
        while (position < count && values[position] >= value) position++;
        if (position >= limit) return count;
        int newCount = Math.min(limit, count + 1);
        for (int i = newCount - 1; i > position; i--) {
            copyCandidateSlot(i - 1, i, paths, lens, costs, maxInstability,
                    prefixes, prefixLens, values);
        }
        System.arraycopy(route, 0, paths[position], 0, routeLen);
        System.arraycopy(prefix, 0, prefixes[position], 0, prefixLen);
        lens[position] = routeLen;
        costs[position] = cost;
        maxInstability[position] = maxInst;
        prefixLens[position] = prefixLen;
        values[position] = value;
        return newCount;
    }

    private static boolean samePrefix(int[] a, int an, int[] b, int bn) {
        if (an != bn) return false;
        for (int i = 0; i < an; i++) if (a[i] != b[i]) return false;
        return true;
    }

    private static void copyCandidateSlot(int from, int to, int[][] paths, int[] lens,
                                          int[] costs, int[] maxInstability, int[][] prefixes,
                                          int[] prefixLens, double[] values) {
        System.arraycopy(paths[from], 0, paths[to], 0, lens[from]);
        System.arraycopy(prefixes[from], 0, prefixes[to], 0, prefixLens[from]);
        lens[to] = lens[from];
        costs[to] = costs[from];
        maxInstability[to] = maxInstability[from];
        prefixLens[to] = prefixLens[from];
        values[to] = values[from];
    }

    private void copyBuildCandidateToBest(int candidate) {
        bestLen = buildBeamLen[candidate];
        bestCost = buildBeamCost[candidate];
        System.arraycopy(buildBeamPath[candidate], 0, bestPath, 0, bestLen);
    }

    private int predictDisrupt(GameState s, int player, int[] plannedRoute, int plannedLen,
                               int reserveMs) {
        prepareDisruptData(s, player);
        for (int i = 0; i < plannedLen; i++) {
            int c = plannedRoute[i];
            if (s.canBuild(c)) myPlanByRegion[s.regionId[c]] += 1;
        }
        double bestValue = P.DISRUPT_MIN;
        int best = -1, fallback = -1;
        double fallbackBest = 0;
        for (int r = 0; r < s.regionCount && !timer.up(reserveMs); r++) {
            if (s.regionInked[r] || s.regionHasTown(r)) continue;
            int needed = Math.max(1, GameState.INK_THRESHOLD - s.regionInstability[r]);
            int earning = s.turnsLeft() - needed;
            if (earning <= 0) continue;
            double balance = P.W_FUTURE_TRACK * oppTracks[r] + P.W_OPP_ROUTE * oppRouteByRegion[r]
                    - P.W_FUTURE_OWN * myTracks[r];
            if (oppTracks[r] == 0 && myTracks[r] == 0) continue;
            double value = disruptValue(s, player, r, false);
            if (value > bestValue) {
                bestValue = value;
                best = r;
            }
            if (value > fallbackBest && value > 0) {
                fallbackBest = value;
                fallback = r;
            }
        }
        return best >= 0 ? best : P.ALWAYS_DISRUPT ? fallback : -1;
    }

    private double replyAwareValue(GameState s, int me, int buildCandidate, int reply,
                                   int replyDisrupt) {
        return replyAwareValue(s, me, buildCandidate, reply, replyDisrupt, -1);
    }

    private double replyAwareValue(GameState s, int me, int buildCandidate, int reply,
                                   int replyDisrupt, int ownDisrupt) {
        simulatePredictedTurn(s, me, buildBeamPrefix[buildCandidate],
                buildBeamPrefixLen[buildCandidate], replyBeamPrefix[reply],
                replyBeamPrefixLen[reply], replyDisrupt, ownDisrupt, sim);
        int opp = 1 - me;
        double immediate = (sim.score[me] - sim.score[opp])
                - replyBaselineScoreDiff[reply];

        completionState.copyFrom(sim);
        int remainingPaint = 0, maxInst = buildBeamMaxInst[buildCandidate];
        for (int i = 0; i < buildBeamLen[buildCandidate]; i++) {
            int c = buildBeamPath[buildCandidate][i];
            if (completionState.inked[c]) return Double.NEGATIVE_INFINITY;
            if (completionState.canBuild(c)) {
                remainingPaint += completionState.placeCost(c);
                maxInst = Math.max(maxInst,
                        completionState.regionInstability[completionState.regionId[c]]);
                completionState.owner[c] = me;
            }
        }
        Rules.updateConnections(completionState, pathing);
        double gain = evalState(completionState, me) - replyBaselineValue[reply];
        int turnsToFinish = (remainingPaint + GameState.PAINT_PER_TURN - 1) / GameState.PAINT_PER_TURN;
        int earning = Math.min(sim.turnsLeft(), P.HORIZON) - turnsToFinish;
        if (earning <= 0) return immediate;
        double risk = Math.max(0, 1 - P.W_RISK * maxInst / GameState.INK_THRESHOLD);
        return immediate + (gain * earning * risk - P.W_COST * remainingPaint) / (turnsToFinish + 1);
    }

    private void simulatePredictedTurn(GameState before, int me, int[] ownCells, int ownCount,
                                       int[] replyCells, int replyCount, int replyDisrupt,
                                       GameState target) {
        simulatePredictedTurn(before, me, ownCells, ownCount, replyCells, replyCount, replyDisrupt, -1, target);
    }

    private void simulatePredictedTurn(GameState before, int me, int[] ownCells, int ownCount,
                                       int[] replyCells, int replyCount, int replyDisrupt,
                                       int ownDisrupt, GameState target) {
        target.copyFrom(before);
        int[] empty = prefixBuf;
        int[] mine = ownCells == null ? empty : ownCells;
        if (me == 0) Rules.applyPlacements(target, mine, ownCount, replyCells, replyCount);
        else Rules.applyPlacements(target, replyCells, replyCount, mine, ownCount);
        if (replyDisrupt >= 0) Rules.disrupt(target, replyDisrupt);
        if (ownDisrupt >= 0) Rules.disrupt(target, ownDisrupt);
        Rules.inkUnstable(target);
        Rules.updateConnections(target, pathing);
        Rules.scoreTurn(target, null);
        target.turn++;
    }

    /** Strictly better raw income wins; ties preserve the historical direction, never vetoing. */
    boolean preferReverseBuild(GameState s, int me, int budget, int[] route, int len) {
        int forward = prefixIncome(s, me, budget, route, len, false);
        int reverse = prefixIncome(s, me, budget, route, len, true);
        return reverse > forward;
    }

    /** Scratch simulation uses the same cost skipping and uncontested-first order as execution. */
    int prefixIncome(GameState s, int me, int budget, int[] route, int len, boolean reverse) {
        sim.copyFrom(s);
        for (int pass = 0; pass < 2 && budget > 0; pass++) {
            for (int i = 0; i < len && budget > 0; i++) {
                int c = route[reverse ? len - 1 - i : i];
                if (!sim.canBuild(c) || contested[c] != (pass == 1)) continue;
                int cost = sim.placeCost(c);
                if (cost > budget) continue;
                budget -= cost;
                sim.owner[c] = me;
            }
        }
        Rules.updateConnections(sim, pathing);
        Rules.incomePerTurn(sim, inc1);
        return inc1[me] - inc1[1 - me];
    }

    /** Simulate exactly the affordable placement order, not the fully completed route. */
    private boolean buildPrefixNonLosing(GameState s, int me, int budget, int len) {
        sim.copyFrom(s);
        for (int pass = 0; pass < 2 && budget > 0; pass++) {
            for (int i = 0; i < len && budget > 0; i++) {
                int c = pathBuf[i];
                if (!sim.canBuild(c) || contested[c] != (pass == 1)) continue;
                int cost = sim.placeCost(c);
                if (cost > budget) continue;
                budget -= cost;
                sim.owner[c] = me;
            }
        }
        return buildIncomeNonLosing(s, me);
    }

    /** The core computes incomes; this is only a strategy veto, without future opponent moves. */
    private boolean buildIncomeNonLosing(GameState before, int me) {
        Rules.updateConnections(sim, pathing);
        Rules.incomePerTurn(before, inc0);
        Rules.incomePerTurn(sim, inc1);
        return inc1[me] - inc1[1 - me] >= inc0[me] - inc0[1 - me];
    }

    /** Best cheap cell next to our network; -1 when no safe extension fits the paint left. */
    private int chooseIdleExtension(GameState s, int me, int budgetNow) {
        double bestValue = 1e-9;
        int best = -1;
        for (int c = 0; c < s.size; c++) {
            if (!s.canBuild(c) || s.placeCost(c) > budgetNow) continue;
            int region = s.regionId[c];
            boolean townRegion = s.regionHasTown(region);
            if (!townRegion && s.regionInstability[region] >= 2) continue;
            int x = s.x(c), y = s.y(c), ownAdjacent = 0, townAdjacent = 0;
            for (int d = 0; d < 4; d++) {
                int nx = x + GameState.DX[d], ny = y + GameState.DY[d];
                if (!s.inBounds(nx, ny)) continue;
                int n = s.cell(nx, ny);
                if (s.owner[n] == me) ownAdjacent++;
                if (s.isTown(n)) townAdjacent++;
            }
            if (ownAdjacent == 0 && townAdjacent == 0) continue;
            double value = ownAdjacent * 10.0 + townAdjacent * 6.0 + (townRegion ? 4.0 : 0.0)
                    - s.regionInstability[region] * 3.0 - s.placeCost(c) * 2.0;
            // Stable deterministic tie-break that differs between players without consuming the
            // candidate-evaluation RNG used by the main search.
            value += ((c * 31 + me * 17 + P.SEED) & 255) * 1e-6;
            if (value > bestValue) {
                if (P.GUARD_BUILD_INCOME) {
                    sim.copyFrom(s);
                    sim.owner[c] = me;
                    if (!buildIncomeNonLosing(s, me)) continue;
                }
                bestValue = value;
                best = c;
            }
        }
        return best;
    }

    // ------------------------------------------------------------------ disrupt

    /** Selects a deterministic, immediately effective fallback without consuming strategy RNG. */
    private int chooseEarlyDisrupt(GameState s, int myId) {
        prepareDisruptData(s, myId);
        double bestValue = P.DISRUPT_MIN;
        int best = -1;
        for (int r = 0; r < s.regionCount; r++) {
            if (s.regionInstability[r] != GameState.INK_THRESHOLD - 1) continue;
            if (oppTracks[r] == 0 && myTracks[r] == 0) continue;
            double value = disruptValue(s, myId, r, false);
            if (value > bestValue) {
                bestValue = value;
                best = r;
            }
        }
        return best;
    }

    /** Placements can change income and whether this ink would end the game, so score it again. */
    private boolean earlyDisruptStillGood(GameState s, int myId, int region) {
        prepareDisruptData(s, myId);
        return disruptValue(s, myId, region, false) > P.DISRUPT_MIN;
    }

    private void prepareDisruptData(GameState s, int myId) {
        int opp = 1 - myId;
        Rules.incomePerTurn(s, inc0);
        java.util.Arrays.fill(oppTracks, 0);
        java.util.Arrays.fill(myTracks, 0);
        java.util.Arrays.fill(oppRouteByRegion, 0);
        java.util.Arrays.fill(myPlanByRegion, 0);
        for (int c = 0; c < s.size; c++) {
            int region = s.regionId[c];
            if (s.owner[c] == opp) oppTracks[region]++;
            else if (s.owner[c] == myId) myTracks[region]++;
            if (myRoute[c]) myPlanByRegion[region] += 1;
        }
        for (int i = 0; i < oppLen; i++) {
            int c = oppPath[i];
            if (s.canBuild(c)) oppRouteByRegion[s.regionId[c]] += 1;
        }
    }

    private double disruptValue(GameState s, int myId, int region, boolean noisy) {
        if (region < 0 || region >= s.regionCount || s.regionInked[region] || s.regionHasTown(region)) {
            return Double.NEGATIVE_INFINITY;
        }
        int needed = Math.max(1, GameState.INK_THRESHOLD - s.regionInstability[region]);
        int earning = s.turnsLeft() - needed;
        if (earning <= 0) return Double.NEGATIVE_INFINITY;
        double balance = P.W_FUTURE_TRACK * oppTracks[region] + P.W_OPP_ROUTE * oppRouteByRegion[region]
                - P.W_FUTURE_OWN * myTracks[region] - P.W_FUTURE_OWN * myPlanByRegion[region];
        sim.copyFrom(s);
        Rules.ink(sim, region);
        Rules.updateConnections(sim, pathing);
        Rules.incomePerTurn(sim, inc1);
        int opp = 1 - myId;
        double oppLoss = inc0[opp] - inc1[opp];
        double myLoss = inc0[myId] - inc1[myId];
        double value;
        if (P.USE_CLOSE && needed == 1 && !Rules.anyPairPossible(sim, pathing)) {
            double lead = (s.score[myId] + inc1[myId]) - (s.score[opp] + inc1[opp]);
            if (lead <= 0) return Double.NEGATIVE_INFINITY;
            value = 1e6 + lead;
        } else {
            value = ((oppLoss - P.W_SELF_LOSS * myLoss) * earning + balance) / needed;
            value *= disruptDelayDiscount(needed);
        }
        return noisy ? value * noise() : value;
    }

    private double disruptDelayDiscount(int needed) {
        double discount = 1.0;
        if (P.DISRUPT_DELAY_FACTOR != 1.0) {
            for (int hit = 1; hit < needed; hit++) discount *= P.DISRUPT_DELAY_FACTOR;
        }
        return discount;
    }

    private int chooseDisrupt(GameState s, int myId) {
        if (!P.PROFILE_SEARCH) return chooseDisruptImpl(s, myId);
        long started = System.nanoTime();
        try {
            return chooseDisruptImpl(s, myId);
        } finally {
            profileDisruptNs += System.nanoTime() - started;
        }
    }

    private int chooseDisruptImpl(GameState s, int myId) {
        prepareDisruptData(s, myId);
        int turnsLeft = s.turnsLeft();
        double bestValue = P.DISRUPT_MIN;
        int best = -1;
        double fallbackBest = 0;
        int fallback = -1;
        int r = 0;
        for (; r < s.regionCount && !timer.up(); r++) {
            if (jointTargetScan && buildTimeUp()) break;
            if (s.regionInked[r] || s.regionHasTown(r)) continue;
            int needed = Math.max(1, GameState.INK_THRESHOLD - s.regionInstability[r]);
            int earning = turnsLeft - needed;
            if (earning <= 0) continue;
            double balance = P.W_FUTURE_TRACK * oppTracks[r] + P.W_OPP_ROUTE * oppRouteByRegion[r]
                    - P.W_FUTURE_OWN * myTracks[r] - P.W_FUTURE_OWN * myPlanByRegion[r];
            if (oppTracks[r] == 0 && myTracks[r] == 0) {
                double fb = balance / needed * disruptDelayDiscount(needed);
                if (fb > fallbackBest) {
                    fallbackBest = fb;
                    fallback = r;
                }
                continue;
            }
            double value = disruptValue(s, myId, r, true);
            if (value > bestValue) {
                bestValue = value;
                best = r;
            }
            if (value > fallbackBest && value > 0) {
                fallbackBest = value;
                fallback = r;
            }
        }
        disruptSearchComplete = r == s.regionCount;
        if (best < 0 && P.ALWAYS_DISRUPT) return fallback;
        return best;
    }
}
